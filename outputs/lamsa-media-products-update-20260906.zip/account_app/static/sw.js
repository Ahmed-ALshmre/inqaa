/* Minimal service worker — needed for installability + offline fallback */
const CACHE_NAME = 'soof-mobile-v13';
const APP_SHELL = [
  '/static/css/advisor.css?v=1',
  '/static/js/advisor.js?v=6',
  '/static/css/dashboard.css?v=18',
  '/static/js/dashboard.js?v=17',
  '/static/css/messenger.css?v=3',
  '/static/js/mobile_app.js?v=3',
  '/static/icons/icon-192.png?v=6',
  '/static/icons/icon-512.png?v=6',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      Promise.all(APP_SHELL.map((url) =>
        cache.add(url).catch(() => {})
      ))
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // Only cache same-origin static assets; never cache APIs or HTML pages.
  if (url.origin !== self.location.origin) return;
  if (!url.pathname.startsWith('/static/')) return;

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((res) => {
        if (res && res.status === 200 && res.type === 'basic') {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
        }
        return res;
      }).catch(() => cached);
    })
  );
});
