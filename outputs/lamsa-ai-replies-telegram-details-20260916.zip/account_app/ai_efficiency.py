"""Lossless prompt compaction and durable, at-most-once image recognition."""
import base64
import hashlib
import io
import json
from collections import Counter


def merge_history(history, memory):
    """Retain legacy memory entries absent from the authoritative message history."""
    counts = Counter((m.get('direction'), str(m.get('text') or '').strip()) for m in history)
    missing = []
    for message in memory or []:
        direction = 'incoming' if message.get('role') == 'user' else 'outgoing'
        text = str(message.get('content') or '').strip()
        key = (direction, text)
        if counts[key]:
            counts[key] -= 1
        elif text:
            missing.append({'direction': direction, 'text': text, 'created_at': '',
                            'message_type': 'text'})
    return missing + list(history)


def compact(value):
    if isinstance(value, dict):
        return {k: compact(v) for k, v in value.items() if v is not None and v != '' and v != [] and v != {}}
    if isinstance(value, list):
        return [compact(v) for v in value]
    return value


def dumps(value):
    return json.dumps(compact(value), ensure_ascii=False, separators=(',', ':'))


def init_db(db):
    db.execute('''CREATE TABLE IF NOT EXISTS conversation_pause_state (
        sender_id TEXT PRIMARY KEY, reason TEXT NOT NULL,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    db.execute('''CREATE TABLE IF NOT EXISTS image_recognition_attempts (
        store_id TEXT NOT NULL, sender_id TEXT NOT NULL, fingerprint TEXT NOT NULL,
        status TEXT NOT NULL, result TEXT, catalog_version TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(store_id, sender_id, fingerprint))''')
    db.execute('''CREATE TABLE IF NOT EXISTS ai_usage_events (
        id INTEGER PRIMARY KEY, store_id TEXT, purpose TEXT, model TEXT,
        prompt_tokens INTEGER, completion_tokens INTEGER, reasoning_tokens INTEGER,
        cached_tokens INTEGER, finish_reason TEXT, elapsed_ms INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')


def fingerprint(data_url):
    from PIL import Image, ImageOps
    raw = base64.b64decode(data_url.split(',', 1)[1], validate=True)
    with Image.open(io.BytesIO(raw)) as source:
        image = ImageOps.exif_transpose(source).convert('RGBA')
        return hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()


def recognize_once(db, store, sender, key, catalog, recognize):
    """Commit reservation before external work; an interrupted attempt never retries."""
    version = hashlib.sha256(dumps(catalog).encode()).hexdigest()
    inserted = db.execute('''INSERT OR IGNORE INTO image_recognition_attempts
        (store_id,sender_id,fingerprint,status,catalog_version) VALUES(?,?,?,'started',?)''',
        (store, sender, key, version)).rowcount
    db.commit()
    if not inserted:
        row = db.execute('''SELECT result FROM image_recognition_attempts
            WHERE store_id=? AND sender_id=? AND fingerprint=?''', (store, sender, key)).fetchone()
        return json.loads(row[0]) if row and row[0] else {
            'product_found': False, 'service_error': True,
            'reason': 'Image attempt already started; manual review required',
            'error_code': 'attempt_already_started'}
    try:
        result = recognize()
    except Exception:
        result = {'product_found': False, 'service_error': True,
                  'reason': 'Image recognition failed; manual review required', 'error_code': 'service_error'}
    db.execute('''UPDATE image_recognition_attempts SET status='finished', result=?
        WHERE store_id=? AND sender_id=? AND fingerprint=?''', (dumps(result), store, sender, key))
    db.commit()
    return result


def invalidate_product(db, store, sender, product_id):
    """A rejected association cannot be resurrected by replaying its image."""
    rows = db.execute('''SELECT fingerprint,result FROM image_recognition_attempts
        WHERE store_id=? AND sender_id=? AND status='finished' ''', (store, sender)).fetchall()
    for key, raw in rows:
        result = json.loads(raw or '{}')
        if result.get('product_id') == product_id:
            result = {'product_found': False, 'reason': 'Previous image association rejected; clarify or review manually',
                      'error_code': 'association_rejected'}
            db.execute('''UPDATE image_recognition_attempts SET status='invalidated',result=?
                WHERE store_id=? AND sender_id=? AND fingerprint=?''', (dumps(result), store, sender, key))


def record_usage(db, store, purpose, model, payload, elapsed_ms):
    usage = payload.get('usage') or {}
    completion = usage.get('completion_tokens_details') or {}
    prompt = usage.get('prompt_tokens_details') or {}
    choices = payload.get('choices') or [{}]
    db.execute('''INSERT INTO ai_usage_events
        (store_id,purpose,model,prompt_tokens,completion_tokens,reasoning_tokens,
         cached_tokens,finish_reason,elapsed_ms) VALUES(?,?,?,?,?,?,?,?,?)''',
        (store, purpose, model, usage.get('prompt_tokens'), usage.get('completion_tokens'),
         completion.get('reasoning_tokens'), prompt.get('cached_tokens'),
         choices[0].get('finish_reason'), elapsed_ms))
    db.commit()
